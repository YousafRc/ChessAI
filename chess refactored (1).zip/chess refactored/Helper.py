import pygame

def selected_row(x,y,bpx,bpy):
    for i in range(8):
        if ( (bpy+((i+1)*62)) >= y >= (bpy+(i*62))):
            row = i
    return row

def selected_col(x,y,bpx,bpy):
    for i in range(8):
        if ( (((i+1)*62)+bpx) >= x >= (bpx+(i * 62)) ):
            col = i
    return col


def inter(text):
    num = ['1','2','3','4','5','6','7','8','9','0']
    temp = []
    #[(1, 2), (3, 2)]
    text = list(text)
    for i in text:
        if i in num:
            temp.append(int(i))

    pc = [(7-temp[0],7-temp[1]), (7-temp[2],7-temp[3])]
    return pc
    