import pygame
pygame.init()

window_size = (400, 300)
screen = pygame.display.set_mode(window_size)
pygame.display.set_caption("Image Display Test")

# Load the image
image = pygame.image.load('./images/misc/show.png')  # Adjust path as needed

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    
    screen.blit(image, (50, 50))  # Adjust the position as needed
    pygame.display.update()

pygame.quit()
