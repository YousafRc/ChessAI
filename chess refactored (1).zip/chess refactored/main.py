import pygame
import socket
import requests
import firebase_admin
from firebase_admin import credentials, auth
from GameBoard import GameBoard
from Helper import *
from Ai import *
from Move import Move
import tkinter as tk
from tkinter import filedialog

# Initalize firebase
cred = credentials.Certificate('./chessFirebaseConfig.json')
firebase_admin.initialize_app(cred)


pygame.init()
pygame.font.init()


#--------- Initialize baisics -------------

Black   = (0,0,0)
White   = (255,255,255)
Red     = (255,0,0)
Lime    = (0,255,0)
Blue    = (0,0,255)
Yellow  = (255,255,0)
Cyan    = (0,255,255)
Magenta = (255,0,255)
Silver  = (192,192,192)
Gray    = (128,128,128)
Maroon  = (128,0,0)
Olive   = (128,128,0)
Green   = (0,128,0)
Purple  = (128,0,128)
Teal    = (0,128,128)
Navy    = (0,0,128)

windowWidth  = 600
windowHeight = 520

window  = pygame.display.set_mode((windowWidth,windowHeight))
caption = pygame.display.set_caption('Chess')
screen  = 0
load    = pygame.image.load
clock   = pygame.time.Clock()


myfont1 = pygame.font.SysFont('Comic Sans MS', 35)
myfont2 = pygame.font.Font("./fonts/Hollow.ttf", 100)
myfont3 = pygame.font.Font("./fonts/Evander-ExtraBold.ttf", 100)
myfont4 = pygame.font.Font("./fonts/Evander-ExtraBold.ttf", 30)
myfont5 = pygame.font.Font("./fonts/Evander-ExtraBold.ttf", 37)
myfont6 = pygame.font.Font("./fonts/Evander-ExtraBold.ttf", 25)
myfont7 = pygame.font.Font("./fonts/Evander-ExtraBold.ttf", 70)
myfont8 = pygame.font.Font("./fonts/Evander-ExtraBold.ttf", 40)
myfont9 = pygame.font.Font("./fonts/Evander-ExtraBold.ttf", 18)
l = '\''

boards = [load('./images/boards/chessboard.png') , load('./images/boards/chessboard2.png'),
          load('./images/boards/chessboard3.png'), load('./images/boards/chessboard4.png'),
          load('./images/boards/chessboard5.png')]
piece = [load('./images/pieces/set1/wK.png'), load('./images/pieces/set2/wK2.png'), load('./images/pieces/set3/wK3.png')]
piecename = ['Pieces 1', 'Pieces 2', 'Pieces 3']
boardname = ['Chessboard 1', 'Chessboard 2', 'Chessboard 3',
             'Chessboard 4', 'Chessboard 5']
pieces = ['wp','bp','wR','bR','wN','bN','wB','bB','wQ','bQ','wK','bK']
pieceImages = {}
num  = 0
num2 = 0

gameboard = GameBoard()
validMoves = gameboard.getValidMoves()
chessboard = boards[0]
pieceset = 0
fps = 60

#------- Helper Functions -----------
def wrap_text(text, font, max_width):
    words = text.split(' ')
    lines = []
    current_line = ''
    for word in words:
        test_line = current_line + word + ' '
        if font.size(test_line)[0] <= max_width:
            current_line = test_line
        else:
            lines.append(current_line)
            current_line = word + ' '
    lines.append(current_line) 
    return lines

def textbox(font, text, x, y, color):
    surface = font.render(text, True, color)
    window.blit(surface, (x, y))

def load_images():
    global pieceImages
    l = str(pieceset+1)
    
    if pieceset == 0:
        for i in pieces:
            name = str('./images/pieces/set' + l + '/' + i + '.png')
            pieceImages[i] = load(name)
            pieceImages[i] = pygame.transform.scale(pieceImages[i], (62,62))
            pieceImages[i] = pieceImages[i].convert_alpha()
    else:
        for i in pieces:
            name = str('./images/pieces/set' + l + '/' + i + l + '.png')
            pieceImages[i] = load(name)
            pieceImages[i] = pygame.transform.scale(pieceImages[i], (62,62))
            pieceImages[i] = pieceImages[i].convert_alpha()     

def draw_board(surface, chessboard, vm, gb, sqq, bpx,bpy):
    surface.blit(chessboard, (bpx,bpy))
    Highlight(surface, vm, sqq, gb, bpx,bpy)

    for r in range(8):
        for c in range(8):
            x = c*62
            y = r*62

            p = gb.board[r][c]
            if p != '--':
                surface.blit(pieceImages[p], (x+bpx,y+bpy))

def Highlight(surface, vm, sqq,gb, bpx,bpy):

    if sqq != ():
        r,c = sqq

        if ((gb.board[r][c][0] == 'w') and (gb.wMove == True)) or\
           ((gb.board[r][c][0] == 'b') and (gb.wMove == False)):

           square = pygame.Surface((62,62))
           square.set_alpha(200)
           square.fill(Purple)

           x = ((c*62) +1)+bpx
           y = ((r*62) +1)+bpy

           surface.blit(square, (x,y))
           pygame.draw.rect(window, Black, (x,y,62,62), 1)

           square.fill(Red)
           for m in vm:
               if m.stRow == r and m.stCol == c:
                   x = ((m.edCol*62) +1) +bpx
                   y = ((m.edRow*62) +1) +bpy

                   surface.blit(square, (x,y))
                   pygame.draw.rect(window, Black, (x,y,62,62), 1)

def register_user(email, password):
    try:
        user = auth.create_user(
            email=email,
            password=password
        )
        print('Successfully created new user:', user.uid)
        return True, 'no error'
    except Exception as e:
        print('Error creating new user:', e)
        return False, e

def firebase_login(email, password):
    api_key = 'AIzaSyCb38cz2DoC9_M60CoL56EUQTqdy4nrcZY'
    request_url = f"https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key={api_key}"
    headers = {"Content-Type": "application/json"}
    data = {
        "email": email,
        "password": password,
        "returnSecureToken": True
    }

    response = requests.post(request_url, json=data, headers=headers)
    if response.status_code == 200:
        user_info = response.json()
        print("Login successful.")
        print("ID Token:", user_info["idToken"])  # ID Token can be used to access Firebase services securely
        return user_info
    else:
        print("Failed to log in:", response.json()["error"]["message"])
        return None

def save_chess_moves(gameboard):
    # Hide the main Tkinter window
    root = tk.Tk()
    root.withdraw()

    # Open a file dialog to choose where to save the file
    file_path = filedialog.asksaveasfilename(defaultextension=".txt",
                                             filetypes=[("Text files", "*.txt"), ("All files", "*.*")])
    if file_path:  # If a file was selected
        alphabetChecker = {1: 'a', 2: 'b', 3: 'c', 4: 'd', 5: 'e', 6: 'f', 7: 'g', 8: 'h'}
        with open(file_path, 'w') as file:
            indexMove = 1
            for singlemove in gameboard.moveLogStack:
                colLetter = alphabetChecker[singlemove.stCol + 1]
                rowNumber = singlemove.stRow + 1

                colLetter2 = alphabetChecker[singlemove.edCol + 1]
                rowNumber2 = singlemove.edRow + 1
                
                move_str = f"{indexMove}: {colLetter}{rowNumber} to {colLetter2}{rowNumber2}\n"
                file.write(move_str)
                indexMove += 1
        print(f'saved log to "{file_path}"')


load_images()

#----- All pages of game ----------
error_message = ''

def error_page():
    global screen, error_message

    max_width = 250 
    line_height = 40 
    start_y = 200  
    wt,ht = myfont3.size("Chess")
    xt = int((windowWidth /2) - (wt/2))
    xt = int((windowWidth /2) - (wt/2))
    yt = ht

    while screen == 10: 
        p, m = pygame.mouse.get_pos()
        window.fill(Black)
        clock.tick(fps)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                screen = 9

            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if (0<p<41) and (0<m<41):
                        screen = 2


        textbox(myfont3, 'Error', 180, 50, White) 

        pygame.draw.line(window, White, (7,20), (20,4), 5)
        pygame.draw.line(window, White, (7,20), (20,36), 5)
        pygame.draw.line(window, White, (7,20), (35,20), 5)
        pygame.draw.rect(window, White, (0,0,41,41), 4)

        for i, line in enumerate(error_message):
            text_surface = myfont8.render(line, True, Red)
            window.blit(text_surface, (30, start_y + i * line_height))

        pygame.display.update()
                   
def menu():
    global screen

    # Loading the pictures and scaling them to fit the screen
    # Also set the coordinates for each picture
    knl = load('./images/pieces/set1/wN.png')
    knl2= load('./images/pieces/set1/wN.png')
    pwl = load('./images/pieces/set1/wp.png')
    pwl2= load('./images/pieces/set1/wp.png')
    knl = pygame.transform.scale(knl , (150,150))
    knl2= pygame.transform.scale(knl2, (180,180))
    pwl = pygame.transform.scale(pwl , (150,150))
    pwl2= pygame.transform.scale(pwl2, (180,180))

    x1 = windowWidth //2 -150
    y1 = windowHeight//2 -75
    x2 = windowWidth //2 +25
    y2 = windowHeight//2 -75
    wt,ht = myfont3.size("Chess")
    xt = int((windowWidth /2) - (wt/2))
    yt = ht

    while screen == 0:
        p,m = pygame.mouse.get_pos()
        window.fill(Black)
        clock.tick(fps)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                screen = 9

            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if (x1+150>p>x1) and (y1+150>m>y1):
                        screen = 1

                    elif (x2+150>p>x2) and (y2+150>m>y2):
                        screen = 2

            

        if (x1+150>p>x1) and (y1+150>m>y1):
            window.blit(knl2, (x1-15,y1-15))
        else:
            window.blit(knl, (x1, y1))




        if (x2+150>p>x2) and (y2+150>m>y2):
            window.blit(pwl2, (x2-15,y2-15))
        else:
            window.blit(pwl, (x2, y2))

        textbox(myfont3, 'Chess', xt, 0, White)
        textbox(myfont4, 'Login', x1+50, y1+150, White)
        textbox(myfont4, 'Register', x2+10, y2+150, White)
        pygame.draw.rect(window, White, (xt,yt,wt,20))
        
        pygame.display.update()

def login():
    global screen

    wt,ht = myfont3.size("Chess")
    xt = int((windowWidth /2) - (wt/2))
    xt = int((windowWidth /2) - (wt/2))
    yt = ht

    toggle_state = True
    
    eye_open_img = load('./images/misc/show.png')
    eye_closed_img = load('./images/misc/hide.png')

    desired_dimensions = (50, 50) 
    eye_open_img = pygame.transform.scale(eye_open_img, desired_dimensions)
    eye_closed_img = pygame.transform.scale(eye_closed_img, desired_dimensions)



    us = False
    pw = False

    ttext = ''
    btext = ''
    atext = ''
    errormessage=''

    count = 0

    logout_button_width = 100
    logout_button_height = 40
    logout_button_x = windowWidth - logout_button_width - 20  # Adjusted for padding
    logout_button_y = 10
    corner_radius = 10

    while screen == 1:
        p,m = pygame.mouse.get_pos()
        window.fill(Black)
        clock.tick(fps)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                screen = 9

            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if (xt+150+185 < p < xt+150+185+30) and (ht+140 < m < ht+140+45):  # Adjust coordinates as needed
                        toggle_state = not toggle_state

                    if (0<p<41) and (0<m<41):
                        screen = 0

                    elif ((xt+150)<p<(xt+150+180)) and ((ht+60)<m<(ht+60+45)):
                        us = True
                        pw = False
                        count = 0

                    elif ((xt+150)<p<(xt+150+180)) and ((ht+140)<m<(ht+140+45)):
                        us = False
                        pw = True
                        count = 0

                    elif ((xt+60)<p<(xt+60+150)) and ((400)<m<(450)):
                        us = False
                        pw = False
                        count = 0
                        user_info = firebase_login(ttext, btext)
                        if user_info:
                            # Login successful, proceed accordingly
                            print("logged in sir")
                            screen = 3
                        else:
                            # Login failed, handle accordingly
                            print("Login failed.")
                            errormessage = 'Login failed'
                            ttext = ''
                            btext = ''

                        
                        

                    else:
                        us = False
                        pw = False
                        count = 0

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_TAB:
                    if us:
                        us = False
                        pw = True
                    elif pw:
                        us = True  # Set to True if you want to cycle back to the username field
                        pw = False
                    count = 0  # Reset the blinking cursor count if needed
                    continue  

                if us == True:
                    if event.key == pygame.K_BACKSPACE:
                        ttext = ttext[:-1]
                    else:
                        ttext += event.unicode
                        width, height = myfont6.size(ttext)

                        if width > 178:
                            ttext = ttext[:-1]

                elif pw == True:
                    if event.key == pygame.K_BACKSPACE:
                        btext = btext[:-1]
                        atext = atext[:-1]
                    else:
                        btext += event.unicode
                        if (len(event.unicode) != 0):
                            atext += '*' if toggle_state else event.unicode  # Show asterisks or characters based on toggle_state
                            
                        width, height = myfont6.size(atext if toggle_state else btext)  # Check width based on what's being displayed

                        if width > 178:
                            btext = btext[:-1]
                            atext = atext[:-1]

        textbox(myfont3, 'Chess', xt, 0, White)
        
        textbox(myfont6, 'Email:', xt-30, ht+60, White)
        textbox(myfont6, errormessage, 210, 350, White)
        pygame.draw.rect(window, White, (xt+150, ht+60, 180, 45),5)
        if us == True:
            width,height = myfont6.size(ttext)

            xl = xt+150 + width+3
            yl = ht+60 + 5
            w = 2
            h = 35

            if (0 <= count <= 10):
                pygame.draw.rect(window, White, (xl,yl,w,h))
            elif count >30:
                count = 0


        textbox(myfont6, 'Password:', xt-30, ht+140, White)
        pygame.draw.rect(window, White, (xt+150, ht+140, 180, 45),5)
        if pw == True:
            width,height = myfont6.size(atext)

            xl = xt+150 + width+3
            yl = ht+140 + 5
            w = 2
            h = 35

            if (0 <= count <= 10):
                pygame.draw.rect(window, White, (xl,yl,w,h))
            elif count >30:
                count = 0
                

        # display the back button
        pygame.draw.line(window, White, (7,20), (20,4), 5)
        pygame.draw.line(window, White, (7,20), (20,36), 5)
        pygame.draw.line(window, White, (7,20), (35,20), 5)
        pygame.draw.rect(window, White, (0,0,41,41), 4)

        
        pygame.draw.rect(window, White, (xt,yt,wt,20))

        textsurface1 = myfont6.render(ttext, False, White)
        window.blit(textsurface1, ((xt+153),(ht+63)))

        if (toggle_state == False):
            textsurface2 = myfont6.render(btext, False, White)
        else :
            textsurface2 = myfont6.render(atext, False, White)
            
        window.blit(textsurface2, ((xt+153),(ht+143)))

        if ((xt+60)<p<(xt+60+150)) and ((400)<m<(450)):
            hover_increase=5
            button_color=(100, 100, 255) 

            
        else:
            hover_increase=0
            button_color=White

        
        # show pw button
        toggle_button_color = Green if toggle_state else Red 
        pygame.draw.rect(window, toggle_button_color, (xt+150+185, ht+140, 30, 45))
        if toggle_state:
            window.blit(eye_closed_img, (xt+150+185, ht+140))  

        else:
            window.blit(eye_open_img, (xt+150+185, ht+140)) 


        button_width = 160 + hover_increase * 2
        button_height = 60 + hover_increase * 2
        button_x = xt+60 - hover_increase
        button_y = 400 - hover_increase

            # Draw rounded rectangle for button
        pygame.draw.rect(window, button_color, (button_x + corner_radius, button_y, button_width - corner_radius * 2, button_height))
        pygame.draw.rect(window, button_color, (button_x, button_y + corner_radius, button_width, button_height - corner_radius * 2))
        pygame.draw.ellipse(window, button_color, (button_x, button_y, corner_radius * 2, corner_radius * 2))
        pygame.draw.ellipse(window, button_color, (button_x + button_width - corner_radius * 2, button_y, corner_radius * 2, corner_radius * 2))
        pygame.draw.ellipse(window, button_color, (button_x, button_y + button_height - corner_radius * 2, corner_radius * 2, corner_radius * 2))
        pygame.draw.ellipse(window, button_color, (button_x + button_width - corner_radius * 2, button_y + button_height - corner_radius * 2, corner_radius * 2, corner_radius * 2))

        # Render "Logout" text on the button
        text_surf = myfont6.render('Done', True, Black)  # Make sure myfont6 is defined and suitable for the button size
        text_rect = text_surf.get_rect(center=(button_x + button_width / 2, button_y + button_height / 2))
        window.blit(text_surf, text_rect)

        pygame.display.update()
        count += 1

def register():
    global screen, error_message
    
    wt,ht = myfont3.size("Chess")
    xt = int((windowWidth /2) - (wt/2))
    xt = int((windowWidth /2) - (wt/2))
    yt = ht

    fn = False
    ln = False
    un = False
    pw = False

    ftext = ''
    ltext = ''
    utext = ''
    ptext = ''

    errormessage=''
    max_width = 350  
    line_height = 50 
    
    start_y = 36

    count = 0

    logout_button_width = 100
    logout_button_height = 40
    logout_button_x = windowWidth - logout_button_width - 20  # Adjusted for padding
    logout_button_y = 10
    corner_radius = 10

    while screen == 2:
        p,m = pygame.mouse.get_pos()
        window.fill(Black)
        clock.tick(fps)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                screen = 9

            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if (0<p<41) and (0<m<41):
                        screen = 0

                    if ((xt+160)<p<(xt+160+180)) and ((160)<m<(200)):
                        fn = True
                        ln = False
                        un = False
                        pw = False

                    elif ((xt+160)<p<(xt+160+180)) and ((210)<m<(250)):
                        fn = False
                        ln = True
                        un = False
                        pw = False

                    elif ((xt+160)<p<(xt+160+180)) and ((260)<m<(300)):
                        fn = False
                        ln = False
                        un = True
                        pw = False

                    elif ((xt+160)<p<(xt+160+180)) and ((310)<m<(350)):
                        fn = False
                        ln = False
                        un = False
                        pw = True

                    elif ((xt+60)<p<(xt+60+150)) and ((400)<m<(450)):
                        
                        fn = False
                        ln = False
                        un = False
                        pw = False
                        success, error = register_user(utext, ptext)
                        if success:
                            # Navigate away from the register screen or reset fields
                            print("Navigate to another screen or reset input fields")
                            screen = 0
                        else:
                            # Show an error message on the screen
                            print(error)
                            ftext = ''
                            ltext = ''
                            utext = ''
                            ptext = ''
                            error_message=wrap_text(str(error), myfont6, max_width)
                            screen=10

                    else:
                        fn = False
                        ln = False
                        un = False
                        pw = False
                        count = 0

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_TAB:
                    if fn:
                        fn = False
                        ln = True
                    elif ln:
                        ln = False
                        un = True
                    elif un:
                        un = False
                        pw = True
                    elif pw:
                        pw = False
                        fn = True
                    count = 0  
                    continue  

                if fn:
                    if event.key == pygame.K_BACKSPACE:
                        ftext = ftext[:-1]
                    else:
                        ftext += event.unicode
                        width, height = myfont6.size(ftext)

                        if width > 175:
                            ftext = ftext[:-1]

                elif ln:
                    if event.key == pygame.K_BACKSPACE:
                        ltext = ltext[:-1]
                    else:
                        ltext += event.unicode
                        width, height = myfont6.size(ltext)

                        if width > 175:
                            ltext = ltext[:-1]

                elif un:
                    if event.key == pygame.K_BACKSPACE:
                        utext = utext[:-1]
                    else:
                        utext += event.unicode
                        width, height = myfont6.size(utext)

                        if width > 240:
                            utext = utext[:-1]

                elif pw:
                    if event.key == pygame.K_BACKSPACE:
                        ptext = ptext[:-1]
                    else:
                        ptext += event.unicode
                        width, height = myfont6.size(ptext)

                        if width > 175:
                            ptext = ptext[:-1]


                





        textbox(myfont3, 'Chess', xt, 0, White)

        textbox(myfont4, 'FirstName', xt, 160, White)

        for i, line in enumerate(errormessage):
            text_surface = myfont5.render(line, True, Red)
            window.blit(text_surface, (xt+160, start_y + i * line_height))
        
        pygame.draw.rect(window, White, (xt+160, 160, 180, 40), 5)

        if fn == True:
            width,height = myfont6.size(ftext)

            xl = xt+160 + width+3
            yl = 160 + 5
            w = 2
            h = 35

            if (0 <= count <= 10):
                pygame.draw.rect(window, White, (xl,yl,w,h))
            elif count >30:
                count = 0


        
        textbox(myfont6, ' Last Name:', xt, 210, White)
        pygame.draw.rect(window, White, (xt+160, 210, 180, 40), 5)

        if ln == True:
            width,height = myfont6.size(ltext)

            xl = xt+160 + width+3
            yl = 210 + 5
            w = 2
            h = 35

            if (0 <= count <= 10):
                pygame.draw.rect(window, White, (xl,yl,w,h))
            elif count >30:
                count = 0


        
        textbox(myfont6, '            email:', xt-6, 260, White)
        pygame.draw.rect(window, White, (xt+160, 260, 250, 40), 5)

        if un == True:
            width,height = myfont6.size(utext)

            xl = xt+160 + width+3
            yl = 260 + 5
            w = 2
            h = 35

            if (0 <= count <= 10):
                pygame.draw.rect(window, White, (xl,yl,w,h))
            elif count >30:
                count = 0



        
        textbox(myfont6, '  Password:', xt, 310, White)
        pygame.draw.rect(window, White, (xt+160, 310, 180, 40), 5)

        if pw == True:
            width,height = myfont6.size(ptext)

            xl = xt+160 + width+3
            yl = 310 + 5
            w = 2
            h = 35

            if (0 <= count <= 10):
                pygame.draw.rect(window, White, (xl,yl,w,h))
            elif count >30:
                count = 0
        
        pygame.draw.line(window, White, (7,20), (20,4), 5)
        pygame.draw.line(window, White, (7,20), (20,36), 5)
        pygame.draw.line(window, White, (7,20), (35,20), 5)
        pygame.draw.rect(window, White, (0,0,41,41), 4)
        pygame.draw.rect(window, White, (xt,yt,wt,20))

        textsurface1 = myfont6.render(ftext, False, White)
        window.blit(textsurface1, ((xt+165),(164)))

        textsurface2 = myfont6.render(ltext, False, White)
        window.blit(textsurface2, ((xt+165),(214)))

        textsurface3 = myfont6.render(utext, False, White)
        window.blit(textsurface3, ((xt+165),(264)))

        textsurface4 = myfont6.render(ptext, False, White)
        window.blit(textsurface4, ((xt+165),(314)))



        if ((xt+60)<p<(xt+60+150)) and ((400)<m<(450)):
            hover_increase=5
            button_color=(100, 100, 255) 
    

            
        else:
            hover_increase = 0
            button_color=White

        
        button_width = 160 + hover_increase * 2
        button_height = 60 + hover_increase * 2
        button_x = xt+60 - hover_increase
        button_y = 400 - hover_increase

            # Draw rounded rectangle for button
        pygame.draw.rect(window, button_color, (button_x + corner_radius, button_y, button_width - corner_radius * 2, button_height))
        pygame.draw.rect(window, button_color, (button_x, button_y + corner_radius, button_width, button_height - corner_radius * 2))
        pygame.draw.ellipse(window, button_color, (button_x, button_y, corner_radius * 2, corner_radius * 2))
        pygame.draw.ellipse(window, button_color, (button_x + button_width - corner_radius * 2, button_y, corner_radius * 2, corner_radius * 2))
        pygame.draw.ellipse(window, button_color, (button_x, button_y + button_height - corner_radius * 2, corner_radius * 2, corner_radius * 2))
        pygame.draw.ellipse(window, button_color, (button_x + button_width - corner_radius * 2, button_y + button_height - corner_radius * 2, corner_radius * 2, corner_radius * 2))

        # Render "Logout" text on the button
        text_surf = myfont6.render('Done', True, Black)  # Make sure myfont6 is defined and suitable for the button size
        text_rect = text_surf.get_rect(center=(button_x + button_width / 2, button_y + button_height / 2))
        window.blit(text_surf, text_rect)

        pygame.display.update()
        count += 1

def game_menu():
    global screen
    knl = load('./images/pieces/set1/wN.png')
    knl2= load('./images/pieces/set1/wN.png')
    pwl = load('./images/pieces/set1/wp.png')
    pwl2= load('./images/pieces/set1/wp.png')
    rkl = load('./images/pieces/set1/wR.png')
    rkl2= load('./images/pieces/set1/wR.png')
    bsl = load('./images/pieces/set1/wB.png')
    bsl2= load('./images/pieces/set1/wB.png')
    sett = load('./images/misc/settings.png')

    
    knl = pygame.transform.scale(knl , (150,150))
    knl2= pygame.transform.scale(knl2, (180,180))
    pwl = pygame.transform.scale(pwl , (150,150))
    pwl2= pygame.transform.scale(pwl2, (180,180))
    rkl = pygame.transform.scale(rkl , (150,150))
    rkl2= pygame.transform.scale(rkl2, (180,180))
    bsl = pygame.transform.scale(bsl , (150,150))
    bsl2= pygame.transform.scale(bsl2, (180,180))
    sett = pygame.transform.scale(sett, (50,50))

    y  = 170
    x1 = 0
    x2 = 150
    x3 = 300
    x4 = 450
    
    display_message = ''


    
    wt,ht = myfont3.size("Chess")
    xt = int((windowWidth /2) - (wt/2))
    xt = int((windowWidth /2) - (wt/2))
    yt = ht


    logout_button_width = 100
    logout_button_height = 40
    logout_button_x = windowWidth - logout_button_width - 20 
    logout_button_y = 10
    corner_radius = 10

    
    while screen == 3:
        p,m = pygame.mouse.get_pos()
        window.fill(Black)
        clock.tick(fps)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                screen = 9

            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if (logout_button_x < p < logout_button_x + logout_button_width) and \
                       (logout_button_y < m < logout_button_y + logout_button_height):
                        screen = 0

                    if (0<p<41) and (0<m<41):
                        screen = 0

                    if ((x1)<p<(x1+150)) and ((y)<m<(y+150)):
                        screen = 5

                    if ((x2)<p<(x2+150)) and ((y)<m<(y+150)):
                        screen = 6

                    if ((x3)<p<(x3+150)) and ((y)<m<(y+150)):
                        screen = 7
                        display_message = 'Waiting for player to join ...'

                    if ((x4)<p<(x4+150)) and ((y)<m<(y+150)):
                        screen = 8

                    if ((540)<p<(590)) and ((465)<m<(465+50)):
                        screen = 4


        textbox(myfont3, 'Chess', xt, 0, White)
        pygame.draw.rect(window, White, (xt,yt,wt,20))

            
        if ((x1)<p<(x1+150)) and ((y)<m<(y+150)):
            window.blit(knl2, (x1-15,y-15))
        else:
            window.blit(knl, (x1,y))

        if ((x2)<p<(x2+150)) and ((y)<m<(y+150)):
            window.blit(pwl2, (x2-15,y-15))
        else:
            window.blit(pwl, (x2,y))

        if ((x3)<p<(x3+150)) and ((y)<m<(y+150)):
            window.blit(rkl2, (x3-15,y-15))
        else:
            window.blit(rkl, (x3,y))

        if ((x4)<p<(x4+150)) and ((y)<m<(y+150)):
            window.blit(bsl2, (x4-15,y-15))
        else:
            window.blit(bsl, (x4,y))

        # Check for mouse hover
        is_hover = logout_button_x < p < logout_button_x + logout_button_width and logout_button_y < m < logout_button_y + logout_button_height
        if is_hover:
            hover_increase = 5 
            button_color = (100, 100, 255) 
        else:
            hover_increase = 0
            button_color = White


        window.blit(sett, (540,465))

        textbox(myfont6, 'Player', 50, 315, White)
        textbox(myfont6, '   vs ', 50, 340, White)
        textbox(myfont6, 'Player', 50, 365, White)

        textbox(myfont6, 'Player', 185, 315, White)
        textbox(myfont6, '   vs ', 185, 340, White)
        textbox(myfont6, '  cpu ', 185, 365, White)

        textbox(myfont6, ' Host', 337, 315, White)
        textbox(myfont6, ' Join', 490, 315, White)
        textbox(myfont6, display_message, 100, 450, White)
        
        

        # display the back button
        pygame.draw.line(window, White, (7,20), (20,4), 5)
        pygame.draw.line(window, White, (7,20), (20,36), 5)
        pygame.draw.line(window, White, (7,20), (35,20), 5)
        pygame.draw.rect(window, White, (0,0,41,41), 4)

        # Draw the logout button
        button_width = logout_button_width + hover_increase * 2
        button_height = logout_button_height + hover_increase * 2
        button_x = logout_button_x - hover_increase
        button_y = logout_button_y - hover_increase

        # Draw rounded rectangle for button
        pygame.draw.rect(window, button_color, (button_x + corner_radius, button_y, button_width - corner_radius * 2, button_height))
        pygame.draw.rect(window, button_color, (button_x, button_y + corner_radius, button_width, button_height - corner_radius * 2))
        pygame.draw.ellipse(window, button_color, (button_x, button_y, corner_radius * 2, corner_radius * 2))
        pygame.draw.ellipse(window, button_color, (button_x + button_width - corner_radius * 2, button_y, corner_radius * 2, corner_radius * 2))
        pygame.draw.ellipse(window, button_color, (button_x, button_y + button_height - corner_radius * 2, corner_radius * 2, corner_radius * 2))
        pygame.draw.ellipse(window, button_color, (button_x + button_width - corner_radius * 2, button_y + button_height - corner_radius * 2, corner_radius * 2, corner_radius * 2))

        # Render "Logout" text on the button
        text_surf = myfont6.render('Logout', True, Black)  # Make sure myfont6 is defined and suitable for the button size
        text_rect = text_surf.get_rect(center=(button_x + button_width / 2, button_y + button_height / 2))
        window.blit(text_surf, text_rect)
        
        
        pygame.display.update()

def settings():
    global screen, chessboard, pieceset,num,num2
    wt,ht = myfont7.size("Settings")
    xt = int((windowWidth /2) - (wt/2))


    name  = boardname[num]
    name2 = piecename[num2]

    while screen == 4:
        p,m = pygame.mouse.get_pos()
        window.fill(Black)
        clock.tick(fps)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                screen = 9

            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if (0<p<41) and (0<m<41):
                        screen = 3
                        chessboard = boards[num]
                        pieceset = num2
                        load_images()
                        

                    elif (170<p<190) and (120<m<160):
                        num -= 1
                        if num <0:
                            num = 0
                            name = boardname[num]

                        else:
                            name = boardname[num]

                    elif (390<p<410) and (120<m<160):
                        num += 1
                        if num>len(boardname) -1:
                            num = len(boardname) -1
                            name = boardname[num]
                        else:
                            name = boardname[num]

                    elif (170<p<190) and (350<m<390):
                        num2 -= 1
                        if num2 <0:
                            num2 = 0
                            name2 = piecename[num2]

                        else:
                            name2 = piecename[num2]

                    elif (390<p<410) and (350<m<390):
                        num2 += 1
                        if num2 >len(piecename) -1:
                            num2 = len(piecename) -1
                            name2 = piecename[num2]

                        else:
                            name2 = piecename[num2]
                
                        
                            

        textbox(myfont7, 'Settings', xt,0, White)

        pygame.draw.line(window, White, (170,140), (190,120), 5)
        pygame.draw.line(window, White, (170,140), (190,160), 5)
        pygame.draw.line(window, White, (190,120), (190,160), 5)

        pygame.draw.line(window, White, (390,120), (410,140), 5)
        pygame.draw.line(window, White, (390,160), (410,140), 5)
        pygame.draw.line(window, White, (390,160), (390,120), 5)

        textbox(myfont6,name, 205, 120, White)
        b = pygame.transform.scale(boards[num], (180,180))
        window.blit(b, (203,160) )

        pygame.draw.line(window, White, (170,370), (190,350), 5)
        pygame.draw.line(window, White, (170,370), (190,390), 5)
        pygame.draw.line(window, White, (190,350), (190,390), 5)

        pygame.draw.line(window, White, (390,350), (410,370), 5)
        pygame.draw.line(window, White, (390,390), (410,370), 5)
        pygame.draw.line(window, White, (390,390), (390,350), 5)

        textbox(myfont6,name2, 240, 355, White)
        if num2 == 1:
            p = pygame.transform.scale(piece[num2], (170,120))
            window.blit(p, (210,360))
        elif num2 == 2:
            p = pygame.transform.scale(piece[num2], (75,75))
            window.blit(p, (250,390))
        else:
            p = pygame.transform.scale(piece[num2], (100,100))
            window.blit(p, (240,380))

        


        pygame.draw.line(window, White, (7,20), (20,4), 5)
        pygame.draw.line(window, White, (7,20), (20,36), 5)
        pygame.draw.line(window, White, (7,20), (35,20), 5)
        pygame.draw.rect(window, White, (0,0,41,41), 4)

        

        

        pygame.display.update()

def PVP():
    global screen, chessboard
    

    gameboard  = GameBoard()
    validMoves = gameboard.getValidMoves()
    SQselected   = ()
    playerClicks = []
    moveMade = False
    stSQ =0
    edSQ =0

    bpx = 51
    bpy = 11

    button_width = 30
    button_height = 30
    button_x = windowWidth - button_width - 15
    button1_y = 25 
    button2_y = 75 

    undobutton = load("./images/misc/undo.png")
    undobutton = pygame.transform.scale(undobutton, (button_width, button_height))

    savebutton = load("./images/misc/save.png")
    savebutton = pygame.transform.scale(savebutton, (button_width, button_height))
    
    

    while screen == 5:
        p,m = pygame.mouse.get_pos()
        window.fill(Black)
        clock.tick(fps)

        if moveMade == True:
            validMoves = []
            validMoves = gameboard.getValidMoves()
            moveMade = False


            
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                screen = 9

            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    


                    if (0<p<41) and (0<m<41):
                        screen = 3
                    
                    if (bpx<p<497+bpx) and (bpy<m<497+bpy):
                        row = selected_row(p,m,bpx,bpy)
                        col = selected_col(p,m,bpx,bpy)

                        if SQselected == (row,col):
                            SQselected   = ()
                            playerClicks = []

                        else:
                            SQselected = (row,col)
                            playerClicks.append(SQselected)


                        if len(playerClicks) == 2:
                            move = Move(playerClicks[0], playerClicks[1], gameboard.board)

                            for i in range(len(validMoves)):
                                if move.uqID == validMoves[i].uqID:
                                    gameboard.makeMove(validMoves[i])
                                    moveMade = True
                                    SQselected   = ()
                                    playerClicks = []


                            if not moveMade:
                                playerClicks = [SQselected]

                    if button_x < p < button_x + button_width and button1_y < m < button1_y + button_height:
                        gameboard.undoMove()
                        moveMade = True
                    elif button_x < p < button_x + button_width and button2_y < m < button2_y + button_height:
                       save_chess_moves(gameboard)


            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_z:
                    gameboard.undoMove()
                    moveMade = True

                if event.key == pygame.K_s:
                    moveslog = gameboard.moveLogStack
                    alphabetChecker = {1: 'a', 2: 'b', 3: 'c', 4: 'd', 5: 'e', 6: 'f', 7: 'g', 8: 'h'}
                    
                    with open('chess_moves_log.txt', 'w') as file:
                        indexMove = 1
                        for singlemove in moveslog:
                            colLetter = alphabetChecker[singlemove.stCol + 1]
                            rowNumber = singlemove.stRow + 1

                            colLetter2 = alphabetChecker[singlemove.edCol + 1]
                            rowNumber2 = singlemove.edRow + 1
                            
                            move_str = f"{indexMove}: {colLetter}{rowNumber} to {colLetter2}{rowNumber2}\n"
                            file.write(move_str)
                            indexMove += 1
                        print('saved log to "chess_move_log.txt" file in the root directory')

        pygame.draw.line(window, White, (7,20), (20,4), 5)
        pygame.draw.line(window, White, (7,20), (20,36), 5)
        pygame.draw.line(window, White, (7,20), (35,20), 5)
        pygame.draw.rect(window, White, (0,0,41,41), 4)




        draw_board(window, chessboard, validMoves, gameboard, SQselected,bpx,bpy)
        textbox(myfont9, "a            b            c             d              e            f              g            h", 80, windowHeight-20, White)
        square_size = 62
        for rank in range(1, 9):
            notation = str(9 - rank)
            textbox(myfont9, notation, bpx - 10, bpy + (rank - 1) * square_size + square_size // 2 - 10, White)

        window.blit(undobutton, (button_x, button1_y))
        window.blit(savebutton, (button_x, button2_y))

        turn_text = "WHITE's Turn" if gameboard.wMove else "BLACK's Turn"
        turn_surface = myfont9.render(turn_text, True, White)
        turn_surface_rotated = pygame.transform.rotate(turn_surface, 270)
        turn_indicator_x = windowWidth -35  
        turn_indicator_y = windowHeight / 2 - turn_surface.get_height() / 2  
    
        window.blit(turn_surface_rotated, (turn_indicator_x, turn_indicator_y))

        pygame.display.update()

def PVC():
    global screen, chessboard

    gameboard  = GameBoard()
    validMoves = gameboard.getValidMoves()
    SQselected   = ()
    playerClicks = []
    moveMade = False
    stSQ =0
    edSQ =0

    bpx = 51
    bpy = 11

    
    button_width = 30
    button_height = 30
    button_x = windowWidth - button_width - 15
    button1_y = 25 
    button2_y = 75 

    undobutton = load("./images/misc/undo.png")
    undobutton = pygame.transform.scale(undobutton, (button_width, button_height))

    savebutton = load("./images/misc/save.png")
    savebutton = pygame.transform.scale(savebutton, (button_width, button_height))
    

    while screen == 6:
        p,m = pygame.mouse.get_pos()
        window.fill(Black)
        clock.tick(fps)

        if moveMade == True:
            validMoves = []
            validMoves = gameboard.getValidMoves()
            moveMade = False


            
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                screen = 9

            if gameboard.wMove == False:
                move = get_ai_move(gameboard)
               
                moveMade = True
                
                
            elif gameboard.wMove == True:
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        if (0<p<41) and (0<m<41):
                            screen = 3
                        
                        if (bpx<p<497+bpx) and (bpy<m<497+bpy):
                            row = selected_row(p,m,bpx,bpy)
                            col = selected_col(p,m,bpx,bpy)

                            if SQselected == (row,col):
                                SQselected   = ()
                                playerClicks = []

                            else:
                                SQselected = (row,col)
                                playerClicks.append(SQselected)


                            if len(playerClicks) == 2:
                                move = Move(playerClicks[0], playerClicks[1], gameboard.board)

                                for i in range(len(validMoves)):
                                    if move.uqID == validMoves[i].uqID:
                                        gameboard.makeMove(validMoves[i])
                                        moveMade = True
                                        SQselected   = ()
                                        playerClicks = []


                                if not moveMade:
                                    playerClicks = [SQselected]

                        if button_x < p < button_x + button_width and button1_y < m < button1_y + button_height:
                            gameboard.undoMove()
                            gameboard.undoMove()
                            moveMade = True
                        elif button_x < p < button_x + button_width and button2_y < m < button2_y + button_height:
                            save_chess_moves(gameboard)

                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_z:
                        gameboard.undoMove()
                        moveMade = True

                        
                    if event.key == pygame.K_s:
                        moveslog = gameboard.moveLogStack
                        alphabetChecker = {1: 'a', 2: 'b', 3: 'c', 4: 'd', 5: 'e', 6: 'f', 7: 'g', 8: 'h'}
                        
                        with open('chess_moves_log.txt', 'w') as file:
                            indexMove = 1
                            for singlemove in moveslog:
                                colLetter = alphabetChecker[singlemove.stCol + 1]
                                rowNumber = singlemove.stRow + 1

                                colLetter2 = alphabetChecker[singlemove.edCol + 1]
                                rowNumber2 = singlemove.edRow + 1
                                
                                move_str = f"{indexMove}: {colLetter}{rowNumber} to {colLetter2}{rowNumber2}\n"
                                file.write(move_str)
                                indexMove += 1
                            print('saved log to "chess_move_log.txt" file in the root directory')




        pygame.draw.line(window, White, (7,20), (20,4), 5)
        pygame.draw.line(window, White, (7,20), (20,36), 5)
        pygame.draw.line(window, White, (7,20), (35,20), 5)
        pygame.draw.rect(window, White, (0,0,41,41), 4)



        draw_board(window, chessboard, validMoves, gameboard, SQselected,bpx,bpy)
        textbox(myfont9, "a            b            c             d              e            f              g            h", 80, windowHeight-20, White)
        square_size = 62
        for rank in range(1, 9):
            notation = str(9 - rank)
            textbox(myfont9, notation, bpx - 10, bpy + (rank - 1) * square_size + square_size // 2 - 10, White)

        
        # Draw the first button
        window.blit(undobutton, (button_x, button1_y))
        # Draw the second button
        window.blit(savebutton, (button_x, button2_y))

        
        turn_text = "WHITE'S Turn" if gameboard.wMove else "BLACK'S Turn"
        turn_surface = myfont9.render(turn_text, True, White)
        turn_surface_rotated = pygame.transform.rotate(turn_surface, 270)
        turn_indicator_x = windowWidth -35  
        turn_indicator_y = windowHeight / 2 - turn_surface.get_height() / 2  
    
        window.blit(turn_surface_rotated, (turn_indicator_x, turn_indicator_y))


        pygame.display.update()

def host():
    global screen, chessboard


    gameboard  = GameBoard()
    validMoves = gameboard.getValidMoves()
    SQselected   = ()
    playerClicks = []
    moveMade = False
    stSQ =0
    edSQ =0

    bpx = 51
    bpy = 11

    button_width = 30
    button_height = 30
    button_x = windowWidth - button_width - 15
    button1_y = 25 
    button2_y = 75 

    undobutton = load("./images/misc/undo.png")
    undobutton = pygame.transform.scale(undobutton, (button_width, button_height))

    savebutton = load("./images/misc/save.png")
    savebutton = pygame.transform.scale(savebutton, (button_width, button_height))

    # socket.gethostbyname(socket.gethostname())
    
    BYTES  = 1024
    HOST   = socket.gethostbyname(socket.gethostname())
    PORT   = 1111
    ADDR   = (HOST,PORT)
    CLOSE  = 'quit'

    s = socket.socket()
    s.bind(ADDR)
    s.listen()
    conn, addr = s.accept()



    while screen == 7:
        p,m = pygame.mouse.get_pos()
        window.fill(Black)
        clock.tick(fps)

        
        if moveMade == True:
            validMoves = []
            validMoves = gameboard.getValidMoves()
            moveMade = False

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                screen = 9
                conn.send(CLOSE.encode())
                conn.close()


            if gameboard.wMove == False:
                rmsg = conn.recv(BYTES)
                rmsg = str(rmsg.decode())

                if rmsg == CLOSE:
                    conn.close()
                    screen = 3

                else:
                    
                    pc = inter(rmsg)
                        
                    move = Move(pc[0],pc[1], gameboard.board)
                    gameboard.makeMove(move)
                    moveMade = True
                
                
            elif gameboard.wMove == True:
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        if (0<p<41) and (0<m<41):
                            screen = 3
                            conn.send((CLOSE).encode())
                        
                        if (bpx<p<497+bpx) and (bpy<m<497+bpy):
                            row = selected_row(p,m,bpx,bpy)
                            col = selected_col(p,m,bpx,bpy)

                            if SQselected == (row,col):
                                SQselected   = ()
                                playerClicks = []

                            else:
                                SQselected = (row,col)
                                playerClicks.append(SQselected)


                            if len(playerClicks) == 2:
                                move = Move(playerClicks[0], playerClicks[1], gameboard.board)

                                for i in range(len(validMoves)):
                                    if move.uqID == validMoves[i].uqID:
                                        lig = str(playerClicks)
                                        conn.send(lig.encode())
                                        gameboard.makeMove(validMoves[i])
                                        moveMade = True
                                        SQselected   = ()
                                        playerClicks = []


                                if not moveMade:
                                    playerClicks = [SQselected]

                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_z:
                        gameboard.undoMove()
                        moveMade = True



        pygame.draw.line(window, White, (7,20), (20,4), 5)
        pygame.draw.line(window, White, (7,20), (20,36), 5)
        pygame.draw.line(window, White, (7,20), (35,20), 5)
        pygame.draw.rect(window, White, (0,0,41,41), 4)
        window.blit(savebutton, (button_x, button2_y))



        draw_board(window, chessboard, validMoves, gameboard, SQselected,bpx,bpy)

        textbox(myfont9, "a            b            c             d              e            f              g            h", 80, windowHeight-20, White)
        square_size = 62
        for rank in range(1, 9):
            notation = str(9 - rank)
            textbox(myfont9, notation, bpx - 10, bpy + (rank - 1) * square_size + square_size // 2 - 10, White)
        pygame.display.update()

def join():
    global screen, chessboard

    gameboard  = GameBoard()
    validMoves = gameboard.getValidMoves()
    gameboard.wMove = False
    SQselected   = ()
    playerClicks = []
    moveMade = False
    stSQ =0
    edSQ =0

    bpx = 51
    bpy = 11
    
    ONLINE = True
    BYTES  = 1024
    HOST   = socket.gethostbyname(socket.gethostname())
    PORT   = 1111
    ADDR   = (HOST,PORT)
    CLOSE  = 'quit'

    button_width = 30
    button_height = 30
    button_x = windowWidth - button_width - 15
    button1_y = 25 
    button2_y = 75 

    undobutton = load("./images/misc/undo.png")
    undobutton = pygame.transform.scale(undobutton, (button_width, button_height))

    savebutton = load("./images/misc/save.png")
    savebutton = pygame.transform.scale(savebutton, (button_width, button_height))

    s = socket.socket()
    s.connect(ADDR)


    
    while screen == 8:
        
        p,m = pygame.mouse.get_pos()
        window.fill(Black)
        clock.tick(fps)

        draw_board(window, chessboard, validMoves, gameboard, SQselected,bpx,bpy)

        
        if moveMade == True:
            validMoves = []
            validMoves = gameboard.getValidMoves()
            moveMade = False

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                screen = 9
                s.send((CLOSE).encode())
                ONLINE = False


            if gameboard.wMove == False:
                rmsg = s.recv(BYTES)
                rmsg = str(rmsg.decode())


                if rmsg == CLOSE:
                    screen = 3
                else:
                    pc = inter(rmsg)
                        
                    move = Move(pc[0],pc[1], gameboard.board)
                    gameboard.makeMove(move)
                    moveMade = True
                
                
            elif gameboard.wMove == True:
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        if (0<p<41) and (0<m<41):
                            screen = 3
                        
                        if (bpx<p<497+bpx) and (bpy<m<497+bpy):
                            row = selected_row(p,m,bpx,bpy)
                            col = selected_col(p,m,bpx,bpy)

                            if SQselected == (row,col):
                                SQselected   = ()
                                playerClicks = []

                            else:
                                SQselected = (row,col)
                                playerClicks.append(SQselected)


                            if len(playerClicks) == 2:
                                move = Move(playerClicks[0], playerClicks[1], gameboard.board)

                                for i in range(len(validMoves)):
                                    if move.uqID == validMoves[i].uqID:

                                        msg = str(playerClicks)
                                        s.send((msg.encode()))

                                        if msg == CLOSE:
                                            screen = 3

                                    
                                        gameboard.makeMove(validMoves[i])
                                        moveMade = True
                                        SQselected   = ()
                                        playerClicks = []


                                if not moveMade:
                                    playerClicks = [SQselected]

                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_z:
                        gameboard.undoMove()
                        moveMade = True



        pygame.draw.line(window, White, (7,20), (20,4), 5)
        pygame.draw.line(window, White, (7,20), (20,36), 5)
        pygame.draw.line(window, White, (7,20), (35,20), 5)
        pygame.draw.rect(window, White, (0,0,41,41), 4)

        window.blit(savebutton, (button_x, button2_y))


        draw_board(window, chessboard, validMoves, gameboard, SQselected,bpx,bpy)
        textbox(myfont9, "a            b            c             d              e            f              g            h", 80, windowHeight-20, White)
        square_size = 62
        for rank in range(1, 9):
            notation = str(9 - rank)
            textbox(myfont9, notation, bpx - 10, bpy + (rank - 1) * square_size + square_size // 2 - 10, White)
        pygame.display.update()


#----- game loop --------
while True:

    if screen == 0:
        menu()
    elif screen == 1:
        login()
    elif screen == 2:
        register()
    elif screen == 3:
        game_menu()
    elif screen == 4:
        settings()
    elif screen == 5:
        PVP()
    elif screen == 6:
        PVC()
    elif screen == 7:
        host()
    elif screen == 8:
        join()
    elif screen == 10:
        error_page()
    else:
        pygame.quit()
        break