class Move():
    def __init__(self, startSQ, endSQ, boardState):
        self.stRow = startSQ[0]
        self.edRow = endSQ  [0]
        self.stCol = startSQ[1]
        self.edCol = endSQ  [1]

        self.PieceMoved    = boardState[self.stRow][self.stCol]
        self.PieceCaptured = boardState[self.edRow][self.edCol]
        self.PawnPormotion = False
        
        if ((self.PieceMoved == 'wp') and (self.edRow == 0)) or\
           ((self.PieceMoved == 'bp') and (self.edRow == 7)):

            self.PawnPormotion = True

        self.uqID = (self.stRow*1) +\
                    (self.edRow*10) +\
                    (self.stCol*100) +\
                    (self.edCol*1000)

        self.board = boardState
