from Move import Move

class GameBoard(object):
    def __init__(self):
        self.wKingPos  = (7,4)
        self.bKingPos  = (0,4)
        self.CheckMate = False
        self.StaleMate = False
        self.wMove     = True
        
        self.moveLogStack = []
        self.moveFunction = {
                            'p':self.getPawnMoves,
                            'R':self.getRookMoves,
                            'N':self.getKnightMoves,
                            'B':self.getBishopMoves,
                            'Q':self.getQueenMoves,
                            'K':self.getKingMoves
                            }
        self.board        = [
                            ["bR","bN","bB","bK","bQ","bB","bN","bR"],
                            ["bp","bp","bp","bp","bp","bp","bp","bp"],
                            ["--","--","--","--","--","--","--","--"],
                            ["--","--","--","--","--","--","--","--"],
                            ["--","--","--","--","--","--","--","--"],
                            ["--","--","--","--","--","--","--","--"],
                            ["wp","wp","wp","wp","wp","wp","wp","wp"],
                            ["wR","wN","wB","wQ","wK","wB","wN","wR"]
                            ]


    def getPawnMoves(self, r, c, moves):
        if self.wMove == True:
            if (0<= r <8) and (0<= c <8):
                # forward 1
                if self.board[r-1][c] == '--':
                    moves.append(Move((r,c), (r-1,c), self.board))

                # forward 2
                if (self.board[r-2][c] == '--') and (r==6):
                    moves.append(Move((r,c), (r-2,c), self.board))

                # capture left
                if ((c-1) >=0) and (self.board[r-1][c-1][0] =='b'):
                    moves.append(Move((r,c), (r-1,c-1), self.board))

                # capture right
                if ((c+1) <=7) and (self.board[r-1][c+1][0] =='b'):
                    moves.append(Move((r,c), (r-1,c+1), self.board))

        elif self.wMove == False:
            if (0<= r <=8) and (0<= c <=8):
                # forward 1
                if self.board[r+1][c] == '--':
                    moves.append(Move((r,c), (r+1,c), self.board))

                # forward 2
                if (r == 1):
                    if (self.board[r+2][c] == '--') and (r==1):
                        moves.append(Move((r,c), (r+2,c), self.board))

                # capture left
                if ((c-1) >=0) and (self.board[r+1][c-1][0] =='w'):
                    moves.append(Move((r,c), (r+1,c-1), self.board))

                # capture right
                if ((c+1) <=7) and (self.board[r+1][c+1][0] =='w'):
                    moves.append(Move((r,c), (r+1,c+1), self.board))

                                    
    def getRookMoves(self, r, c, moves):

        RookMoves = ((-1, 0), # left
                     ( 1, 0), # right
                     ( 0,-1), # down
                     ( 0, 1)) # up

        if self.wMove == True:
            enemyColor = 'b'
            allyColor  = 'w'
        else:
            enemyColor = 'w'
            allyColor  = 'b'

        # cycle through all the directions the rook can move
        # if the square is empty then add to moves list
        # if the square is an enemy then add to moves list
        # after an enemy is detected or reach end of board, break out of loop
        
        for m in RookMoves:
            for i in range(1,8):
                edRow = r+(m[0] *i)
                edCol = c+(m[1] *i)

                if (0<= edRow <8) and (0<= edCol <8):
                    edPiece = self.board[edRow][edCol]

                    if edPiece == '--':
                        moves.append(Move((r,c), (edRow,edCol), self.board))
                    elif edPiece[0] == enemyColor:
                        moves.append(Move((r,c), (edRow,edCol), self.board))
                        break
                    else:
                        break
                else:
                    break
                
        
    def getKingMoves(self, r, c, moves):
        
        KingMoves = ((-1,-1), # bottom left
                     (-1, 0), # bottom
                     (-1, 1), # bottom right
                     ( 0,-1), # left
                     ( 0, 1), # right
                     ( 1,-1), # top left
                     ( 1, 0), # top
                     ( 1, 1)) # top right

        if self.wMove == True:
            enemyColor = 'b'
            allyColor  = 'w'
        else:
            enemyColor = 'w'
            allyColor  = 'b'
            
        # loop through 0 to 7 and figure out what the
        # end row is and what the ed collum is
        # check if the square has an ally piece, if it
        # does then dont put the move in the moves list
        
        for i in range(8):
            edRow = r+KingMoves[i][0]
            edCol = c+KingMoves[i][1]

            if (0<= edRow <8) and (0<= edCol <8):
                edPiece = self.board[edRow][edCol]

                if edPiece[0] != allyColor:
                    moves.append(Move((r,c), (edRow,edCol), self.board))
        
    def getBishopMoves(self, r, c, moves):
        
        BishopMoves = ((-1,-1), # bottom left
                       ( 1, 1), # top right
                       ( 1,-1), # bottom right
                       (-1, 1)) # top left

        if self.wMove == True:
            enemyColor = 'b'
            allyColor  = 'w'
        else:
            enemyColor = 'w'
            allyColor  = 'b'

        # loop through all the directions a bishop move
        # for each direction see if the square is empty, if
        # it is then add the move to the moves list
        # if it is an enmey piece then add it to the moves list and break the loop
        
        for m in BishopMoves:
            for i in range(1,8):
                edRow = r+(m[0] *i)
                edCol = c+(m[1] *i)
                
                if (0<= edRow <8) and (0<= edCol <8):
                    edPiece = self.board[edRow][edCol]

                    if edPiece == '--':
                        moves.append(Move((r,c), (edRow,edCol), self.board))
                    elif edPiece[0] == enemyColor:
                        moves.append(Move((r,c), (edRow,edCol), self.board))
                        break
                    else:
                        break
                else:
                    break

        
    def getQueenMoves(self, r, c, moves):
        
        # a queen is basically all the bishop moves and
        # all the rook moves togather so we just call the
        # 2 funtions and that is all we need.
        
        self.getBishopMoves(r, c, moves)
        self.getRookMoves(r, c, moves)

        
    def getKnightMoves(self, r, c, moves):
        KnightMoves = ((-2,-1),
                       (-2, 1),
                       (-1,-2),
                       (-1, 2),
                       ( 1, 2),
                       ( 1,-2),
                       ( 2,-1),
                       ( 2, 1))

        if self.wMove == True:
            enemyColor = 'b'
            allyColor  = 'w'
        else:
            enemyColor = 'w'
            allyColor  = 'b'
            
        # loop through the knght moves and checks if the square is not an
        # ally piece and also checks if there is an enemy piece.
        # Then it adds it to the moves list

        for m in KnightMoves:
            edRow = r + m[0]
            edCol = c + m[1]

            if (0 <= edRow < 8) and (0 <= edCol < 8):
                edPiece = self.board[edRow][edCol]

                if (edPiece[0] != allyColor) or (edPiece[0] == enemyColor) or (edPiece[0] == '--'):
                    moves.append(Move((r,c), (edRow,edCol), self.board))

        
    def inCheck(self):

        #if king in check then return true else return false
        
        if self.wMove == True:
            return self.SQunderAttack(self.wKingPos[0], self.wKingPos[1])
        else:
            return self.SQunderAttack(self.bKingPos[0], self.bKingPos[1])
        
    def SQunderAttack(self, r, c):

        # gets all the possible oppoent moves ands sees if any of them land on the
        # king position. if it does return true or else return false

        self.wMove = not self.wMove
        oppMoves = self.getPossibleMoves()
        self.wMove = not self.wMove

        for m in oppMoves:
            if (m.edRow ==r) and (m.edCol ==c):
                return True

        return False

        
    def getPossibleMoves(self):
        moves = []

        # loops through each square on the board and finds all the
        # possible moves and add it to the moves list.
        
        for r in range(len(self.board)):
            for c in range(len(self.board[r])):
                color = self.board[r][c][0]
                piece = self.board[r][c][1]

                if (color == 'w' and self.wMove == True) or\
                   (color == 'b' and self.wMove == False):

                    self.moveFunction[piece](r, c, moves)

        return moves

                
    def getValidMoves(self):
        moves = self.getPossibleMoves()

        # goes through all the possible moves on the board thats possible
        # then it makes the moves and checks if it is in a check state. if it
        # is then it removes. it undos the move and repeat until it goes through
        # all the moves.
        # after it checks if any more moves are possible, if not then it could
        # either be a check mate or stale mate.

        for i in range(len(moves)-1, -1, -1):
            self.makeMove(moves[i])
            self.wMove = not self.wMove

            if self.inCheck() == True:
                moves.remove(moves[i])

            self.undoMove()
            self.wMove = not self.wMove

        if len(moves) == 0:
            if self.inCheck() == True:
                self.CheckMate = True

            else:
                self.StaleMate = True
        else:
            self.CheckMate = False
            self.StaleMate = False

        return moves


    def makeMove(self, move):

        # makes the move by replacing the starting square with an empty one
        # and moves the piece to the ending square
        # updates the kings position if it is moved and adds the moves to
        # the log stack.
        
        self.board[move.stRow][move.stCol] = '--'
        self.board[move.edRow][move.edCol] = move.PieceMoved
        self.wMove = not self.wMove
        self.moveLogStack.append(move)

        if move.PieceMoved == 'wK':
            self.wKingPos = (move.edRow, move.edCol)
        elif move.PieceMoved == 'bK':
            self.bKingPos = (move.edRow, move.edCol)

        if move.PawnPormotion == True:
            self.board[move.edRow][move.edCol] = move.PieceMoved[0] + 'Q'


    def undoMove(self):

        # checks if the log is empty cause you can remove stuff if stack is empty
        # pops the top most recent moves and makes that move
        # updates the kings position
        
        if len(self.moveLogStack) != 0:
            move = self.moveLogStack.pop()

            self.board[move.stRow][move.stCol] = move.PieceMoved
            self.board[move.edRow][move.edCol] = move.PieceCaptured
            self.wMove = not self.wMove

            if move.PieceMoved == 'wK':
                self.wKingPos = (move.stRow, move.stCol)
            elif move.PieceMoved == 'bK':
                self.bKingPos = (move.stRow, move.stCol)
