def evaluate_board(board, gameboard):
    piece_value = {'K': 1500, 'Q': 900, 'R': 500, 'B': 330, 'N': 320, 'p': 100, '--': 0}
    CHECKMATE_VALUE = 10000
    BEING_CHECKMATED_VALUE = -10000
    pawn_advance_value = [0, 10, 20, 30, 40, 50, 60, 0] 

    if gameboard.CheckMate:
        if gameboard.wMove:  
            return BEING_CHECKMATED_VALUE
        else:  
            return CHECKMATE_VALUE

    if gameboard.StaleMate:
        return 0 

    value = 0
    for r, row in enumerate(board):
        for c, piece in enumerate(row):
            if piece[0] == 'w': 
                value += piece_value.get(piece[1], 0)
                if piece[1] == 'p':  
                    value += pawn_advance_value[r]
            elif piece[0] == 'b':  
                value -= piece_value.get(piece[1].lower(), 0)
                if piece[1].lower() == 'p': 
                    value -= pawn_advance_value[7 - r] 
    return value


def minimax_with_alpha_beta(gameboard, depth, alpha, beta, maximizingPlayer):
    if depth == 0 or gameboard.CheckMate or gameboard.StaleMate:
        evaluation = evaluate_board(gameboard.board, gameboard)
        return evaluation, None

    if maximizingPlayer:
        maxEval = float('-inf')
        bestMove = None
        for move in gameboard.getValidMoves():
            gameboard.makeMove(move)
            evaluation = minimax_with_alpha_beta(gameboard, depth-1, alpha, beta, False)[0]
            gameboard.undoMove()
            if evaluation > maxEval:
                maxEval = evaluation
                bestMove = move
            alpha = max(alpha, evaluation)
            if beta <= alpha:
                break 
        return maxEval, bestMove
    else:
        minEval = float('inf')
        bestMove = None
        for move in gameboard.getValidMoves():
            gameboard.makeMove(move)
            evaluation = minimax_with_alpha_beta(gameboard, depth-1, alpha, beta, True)[0]
            gameboard.undoMove()
            if evaluation < minEval:
                minEval = evaluation
                bestMove = move
            beta = min(beta, evaluation)
            if beta <= alpha:
                break 
        return minEval, bestMove

def get_ai_move(gameboard, depth=3):
    _, move = minimax_with_alpha_beta(gameboard, depth, float('-inf'), float('inf'), gameboard.wMove)
    if move:
        gameboard.makeMove(move)
        return True
    return False